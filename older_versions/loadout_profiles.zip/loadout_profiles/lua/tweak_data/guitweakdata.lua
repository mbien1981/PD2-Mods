Hooks:PostHook(GuiTweakData, "init", "LP:GuiTweakData.init", function(self, tweak_data)
	self.steam_community = "https://steamcommunity.com/"
	self.fbi_files_webpage = "https://fbi.paydaythegame.com/"
end)
