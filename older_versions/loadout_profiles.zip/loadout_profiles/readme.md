Intended for game versions pre U107.
Mainly developed and tested for U37.1 (v1.15.1 @manifest:965602163317350806)
