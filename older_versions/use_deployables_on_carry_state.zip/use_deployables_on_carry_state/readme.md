Allow the player to use their deployables on versions pre u102.
