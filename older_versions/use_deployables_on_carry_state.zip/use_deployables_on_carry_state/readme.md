Allow the player to use their deployables while carrying bags on versions pre u102.
